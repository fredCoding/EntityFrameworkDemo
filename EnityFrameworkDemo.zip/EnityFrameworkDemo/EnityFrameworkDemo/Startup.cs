﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(EnityFrameworkDemo.Startup))]
namespace EnityFrameworkDemo
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
